import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import VotingForm from './components/VotingForm.tsx';
import CandidateList from './components/CandidateList.tsx';
import ResultDisplay from './components/ResultDisplay.tsx';
import { VotingABI } from './components/contracts/VotingABI.js'; // Ensure this is the correct ABI file

import './App.css';

const contractAddress = '0x5FbDB2315678afecb367f032d93F642f64180aa3'; // Replace with your deployed contract address

interface Candidate {
  id: number;
  name: string;
  voteCount: number;
}

const fetchCandidates = async () => {
  // Simulated mock candidates data
  return [
    { id: 1, name: 'Candidate A', voteCount: 0 },
    { id: 2, name: 'Candidate B', voteCount: 0 },
    { id: 3, name: 'Candidate C', voteCount: 0 },
  ];
};

const submitVote = async (candidateId: number, candidates: Candidate[]) => {
  return candidates.map((candidate) =>
    candidate.id === candidateId
      ? { ...candidate, voteCount: candidate.voteCount + 1 }
      : candidate
  );
};

function App() {
  const [contract, setContract] = useState<ethers.Contract | null>(null);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [account, setAccount] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [isMockMode, setIsMockMode] = useState(true);

  useEffect(() => {
    const init = async () => {
      if (isMockMode) {
        const candidatesList = await fetchCandidates();
        setCandidates(candidatesList);
      } else {
        if (typeof window.ethereum !== 'undefined') {
          try {
            // Ensure MetaMask is connected
            await window.ethereum.request({ method: 'eth_requestAccounts' });
            const provider = new ethers.providers.Web3Provider(window.ethereum);
            const signer = provider.getSigner();
            const address = await signer.getAddress();
            setAccount(address);

            // Initialize contract
            const votingContract = new ethers.Contract(contractAddress, VotingABI, signer);
            setContract(votingContract);

            // Fetch candidates count
            const candidatesCount = await votingContract.candidatesCount();
            console.log('Candidates Count:', candidatesCount.toString());

            // Fetch candidates list
            if (candidatesCount.toNumber() > 0) {
              const candidatesList = await votingContract.getCandidates();
              const formattedCandidates = candidatesList.map((candidate: any) => ({
                id: candidate.id.toNumber(),
                name: candidate.name,
                voteCount: candidate.voteCount.toNumber(),
              }));
              setCandidates(formattedCandidates);
            } else {
              console.error('No candidates available in the contract.');
            }
          } catch (error: any) {
            if (error.code === 4001) {
              console.error('User rejected connection request.');
            } else {
              console.error('Error initializing the app:', error);
            }
          }
        } else {
          alert('MetaMask is required to use this app. Install it from https://metamask.io/');
        }
      }
    };

    init();
  }, [isMockMode]);

  const handleVote = async (candidateId: number) => {
    setLoading(true);
    try {
      if (isMockMode) {
        const updatedCandidates = await submitVote(candidateId, candidates);
        setCandidates(updatedCandidates);
      } else if (contract) {
        console.log('Attempting to cast vote for candidate ID:', candidateId);
        const tx = await contract.vote(candidateId);
        await tx.wait(); // Wait for transaction confirmation

        const updatedCandidates = await contract.getCandidates();
        const formattedCandidates = updatedCandidates.map((candidate: any) => ({
          id: candidate.id.toNumber(),
          name: candidate.name,
          voteCount: candidate.voteCount.toNumber(),
        }));

        setCandidates(formattedCandidates);
      } else {
        console.error('Contract is not initialized');
      }
    } catch (error: any) {
      if (error.code === 4001) {
        console.error('User rejected the transaction.');
      } else {
        console.error('Error casting vote:', error);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Decentralized Voting</h1>
        {account && <p>Connected Account: {account}</p>}
        <button onClick={() => setIsMockMode((prev) => !prev)} disabled={loading}>
          {isMockMode ? 'Switch to Blockchain' : 'Switch to Mock'}
        </button>
      </header>
      <main>
        {loading && <p>Processing your vote...</p>}
        {candidates.length === 0 ? (
          <p>No candidates available. Please check the contract or mock service.</p>
        ) : (
          <>
            <VotingForm candidates={candidates} onVote={handleVote} />
            <CandidateList candidates={candidates} />
            <ResultDisplay candidates={candidates} />
          </>
        )}
      </main>
    </div>
  );
}

export default App;
