import React from 'react';

interface Candidate {
  id: number;  
  name: string;
  voteCount: number;
}

interface ResultDisplayProps {
  candidates: Candidate[];
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ candidates }) => {
  if (candidates.length === 0) {
    return (
      <div className="result-display">
        <h2>Current Leader</h2>
        <p>No candidates available or no votes have been cast yet.</p>
      </div>
    );
  }

 
  let maxVoteCount = 0;
  const leaders: Candidate[] = [];

  for (const candidate of candidates) {
    if (candidate.voteCount > maxVoteCount) {
      maxVoteCount = candidate.voteCount;
      leaders.length = 0;  
      leaders.push(candidate);
    } else if (candidate.voteCount === maxVoteCount) {
      leaders.push(candidate);
    }
  }

  return (
    <div className="result-display">
      <h2>Current Leader{leaders.length > 1 ? 's' : ''}</h2>
      {maxVoteCount > 0 ? (
        <ul>
          {leaders.map((leader) => (
            <li key={leader.id}>
              {leader.name} with {leader.voteCount} vote{leader.voteCount > 1 ? 's' : ''}
            </li>
          ))}
        </ul>
      ) : (
        <p>No votes have been cast yet.</p>
      )}
    </div>
  );
};

export default ResultDisplay;
