import React from 'react';

interface Candidate {
  id: number;
  name: string;
  voteCount: number;
}

interface CandidateListProps {
  candidates: Candidate[];
}

const CandidateList: React.FC<CandidateListProps> = ({ candidates }) => {
  if (candidates.length === 0) {
    return (
      <div className="candidate-list">
        <h2>Candidates</h2>
        <p>No candidates available.</p>
      </div>
    );
  }

  return (
    <div className="candidate-list">
      <h2>Candidates</h2>
      <ul>
        {candidates.map((candidate) => (
          <li key={candidate.id}>
            <strong>{candidate.name}</strong> - {candidate.voteCount} vote{candidate.voteCount !== 1 ? 's' : ''}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CandidateList;
