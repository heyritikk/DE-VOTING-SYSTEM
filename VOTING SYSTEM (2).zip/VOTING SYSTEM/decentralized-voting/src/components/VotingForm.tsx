import React, { useState } from 'react';

interface Candidate {
  id: number;
  name: string;
}

interface VotingFormProps {
  candidates: Candidate[];
  onVote: (candidateId: number) => void;
}

const VotingForm: React.FC<VotingFormProps> = ({ candidates, onVote }) => {
  const [selectedCandidate, setSelectedCandidate] = useState<number | null>(null); // Changed from '' to null
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (selectedCandidate !== null) { 
      try {
        onVote(selectedCandidate); 
        setSuccess('Your vote has been cast successfully!');
        setSelectedCandidate(null); 
      } catch (err) {
        setError('Failed to cast your vote. Please try again.');
      }
    }
  };

  return (
    <form onSubmit={handleSubmit} className="voting-form">
      <h2>Cast Your Vote</h2>
      <label htmlFor="candidate-select">Select Candidate</label>
      <select
        id="candidate-select"
        value={selectedCandidate ?? ''} 
        onChange={(e) => {
          const value = parseInt(e.target.value);
          if (!isNaN(value)) setSelectedCandidate(value);
        }}
        required
      >
        <option value="">Select a candidate</option>
        {candidates.map((candidate) => (
          <option key={candidate.id} value={candidate.id}>
            {candidate.name}
          </option>
        ))}
      </select>
      <button type="submit" disabled={selectedCandidate === null}>
        Vote
      </button>
      {error && <p className="error-message">{error}</p>}
      {success && <p className="success-message">{success}</p>}
    </form>
  );
};

export default VotingForm;
