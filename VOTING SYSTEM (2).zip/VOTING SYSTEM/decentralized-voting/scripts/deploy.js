async function main() {
    const [deployer] = await ethers.getSigners();
  
    console.log("Deploying the contract with account:", deployer.address);
  
    const Voting = await ethers.getContractFactory("Voting");
  
    // Pass the required constructor argument - a list of candidate names
    const candidateNames = ["Alice", "Bob", "Charlie"];
    const votingContract = await Voting.deploy(candidateNames);
  
    await votingContract.deployed();
  
    console.log("Voting contract deployed to:", votingContract.address);
  }
  
  main()
    .then(() => process.exit(0))
    .catch((error) => {
      console.error("Error during deployment:", error);
      process.exit(1);
    });
  